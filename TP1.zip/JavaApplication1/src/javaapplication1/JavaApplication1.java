package javaapplication1;

import java.util.Scanner;

public class JavaApplication1 {

public static void main(String[] args) {
 
  int a, b, c, p,may, min, res, prod;
  Scanner scanf = new Scanner (System.in);
  System.out.println("Escribi un numero: ");
  a=scanf.nextInt();
  System.out.println("Escribi otro: ");
  b=scanf.nextInt();
  System.out.println("Escribi un ultimo numero: ");
  c=scanf.nextInt();
   
  if (a==b) {
      if (a==c) {
      System.out.println("Todos los numeros son iguales "); }
      else {
      System.out.println("A y B son iguales "); }
  }
  else if (b==c) {
      System.out.println("B y C son iguales "); }
  else if (a==c) { System.out.println("A y C son iguales "); }
  else System.out.println("Todos los numeros son diferentes ");
p=(a+b+c)/3;
System.out.println("El promedio es " +p);
p=(a+b+c);
System.out.println("La suma de todos es " +p);
 if (a > b) {
            if (a > c) {
                System.out.println("El mayor es: " + a);
                may = a;
                if (b>c){
                min = c;
                res = c;
                }else{
                min = b;
                res = c;
                }
            } else {
                System.out.println("El mayor es: " + c);  
                may = c;
                 if (b>a){
                min = a;
                res = b;
                }else{
                min = b;
                res = a;
                }
            }
        } else if (b > c) {
            System.out.println("El mayor es: " + b);
            may = b;
             if (a>c){
                min = c;
                res = a;
                }else{
                min = a;
                res = c;
                }
        } else {
            System.out.println("El mayor es: " + c);
            may = c;
             if (b>a){
                min = a;
                res = b;
                }else{
                min = b;
                res = a;
                }
        }
 System.out.println ("el menor es:" +min);
  System.out.println("El menor es: " + min);      
        prod = may * min;
        System.out.println("El producto del mayor y el menor es: : " + prod);        
        if (res%3==0){
        System.out.println("El numero restante es divisible por 3");
        }else{
        System.out.println("El resto es no es divisible por 3 ");
}
}
}
