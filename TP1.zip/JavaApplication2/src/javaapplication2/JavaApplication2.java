package javaapplication2;

import java.util.Scanner;

public class JavaApplication2 {

public static void main(String[] args) {
       
    int anio;
   

      Scanner scanf = new Scanner (System.in);
  System.out.println("Ingrese un anio ");
  anio=scanf.nextInt();
           
    if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0)))
System.out.println("El año es bisiesto");
else
System.out.println("El año no es bisiesto");
   
 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    }
   
}

