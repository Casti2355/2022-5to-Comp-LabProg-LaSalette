/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author PC01
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i, n = 0, fac=1;
        
        Scanner scanf = new Scanner (System.in);
  System.out.println("Escribi un numero: ");
  n=scanf.nextInt();
        
        for (i=1; i<=n; i++){
            fac=i*fac;
        }
        System.out.println("el factorial del numero es: " + fac);
    }
    
}
