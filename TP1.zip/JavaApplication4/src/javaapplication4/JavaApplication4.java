package javaapplication4;

import java.util.Scanner;

public class JavaApplication4 {

   
    public static void main(String[] args) {
     
        int a=0, i,cont=0;
       
        Scanner sc = new Scanner (System.in);
     System.out.print ("Escribi un numero: ");
     a=sc.nextInt();
     
     for (i=1; i<=a; i++){
         if (a % i == 0){
         
             System.out.println(i);
             cont++;
         }
   
               
             
        }
       System.out.println("Se puede dividir por "+cont+ " numeros " ) ;

     }
    }