/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

import java.util.Scanner;

/**
 *
 * @author PC01
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b = 0, i;
        Scanner sc = new Scanner(System.in);
        System.out.print("Escribi un numero: ");
        a = sc.nextInt();
       
            for (i=1; i<=10; i++){
                b= a*i;
                System.out.println(b);
            }
        
            }
    }


